sub init()
    m.top.functionName = "resolveStream"
end sub

sub resolveStream()
    vId = m.top.videoId
    if vId = invalid or vId = "" then return

    print "--- RESOLVING VIA LOCAL NODE SERVER FOR ID: "; vId

    ' Local Node.js Server IP
    nodeBaseUrl = "https://yt-dlp.0013290.xyz/stream"

    request = CreateObject("roUrlTransfer")
    port = CreateObject("roMessagePort")
    request.SetMessagePort(port)
    
    request.SetUrl(nodeBaseUrl + "?id=" + vId)
    request.AddHeader("Accept", "application/json")
    request.EnablePeerVerification(false)
    request.EnableHostVerification(false)

    if request.AsyncGetToString()
        ' INCREASED TIMEOUT TO 15 SECONDS FOR HEAVY SEARCH RESOLUTIONS
        msg = wait(15000, port)
        if type(msg) = "roUrlEvent" and msg.GetResponseCode() = 200
            jsonText = msg.GetString()
            if jsonText <> invalid and jsonText <> ""
                json = ParseJson(jsonText)
                if json <> invalid and json.url <> invalid and json.url <> ""
                    print "--- DIRECT VIDEO STREAM RESOLVED: "; json.url
                    m.top.resolvedUrl = json.url
                    if json.audioUrl <> invalid then
                        print "--- DIRECT AUDIO STREAM RESOLVED: "; json.audioUrl
                        m.top.audioUrl = json.audioUrl
                    else
                        m.top.audioUrl = ""
                    end if
                    return
                end if
            end if
        end if
    end if

    print "--- LOCAL SERVER RESOLUTION FAILED FOR ID: "; vId
    m.top.resolvedUrl = ""
    m.top.audioUrl = ""
end sub