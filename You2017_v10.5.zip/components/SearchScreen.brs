sub init()
    m.searchTextDisplay = m.top.findNode("searchTextDisplay")
    m.suggestionsGroup = m.top.findNode("suggestionsGroup")
    m.keyboardContainer = m.top.findNode("keyboardContainer")
    
    m.btnSpaceBg = m.top.findNode("btnSpaceBg")
    m.btnClearBg = m.top.findNode("btnClearBg")
    m.btnSearchBg = m.top.findNode("btnSearchBg")

    m.currentText = ""
    m.gridFocusX = 0
    m.gridFocusY = 0
    m.actionFocusIdx = 0
    m.focusMode = "grid"

    m.keys = [
        ["A", "B", "C", "D", "E", "F", "G"],
        ["H", "I", "J", "K", "L", "M", "N"],
        ["O", "P", "Q", "R", "S", "T", "U"],
        ["V", "W", "X", "Y", "Z", "-", "'"]
    ]

    m.keyNodes = []
    buildKeyboardGrid()
    populateDefaultSuggestions()
    updateFocusUI()
end sub

sub buildKeyboardGrid()
    m.focusCursor = m.keyboardContainer.createChild("Rectangle")
    m.focusCursor.width = 46
    m.focusCursor.height = 46
    m.focusCursor.color = "0xFFFFFFFF"
    m.focusCursor.visible = true

    for y = 0 to m.keys.Count() - 1
        rowNodes = []
        for x = 0 to m.keys[y].Count() - 1
            lbl = m.keyboardContainer.createChild("Label")
            lbl.translation = [x * 52 + 5, y * 52 + 8]
            lbl.width = 36
            lbl.text = m.keys[y][x]
            lbl.horizAlign = "center"
            lbl.color = "0xCCCCCCFF"
            lbl.font = "font:MediumBoldSystemFont"
            rowNodes.Push(lbl)
        end for
        m.keyNodes.Push(rowNodes)
    end for
end sub

sub updateFocusUI()
    if m.focusMode = "grid"
        m.focusCursor.visible = true
        m.focusCursor.translation = [m.gridFocusX * 52, m.gridFocusY * 52]
        
        for y = 0 to m.keys.Count() - 1
            for x = 0 to m.keys[y].Count() - 1
                if x = m.gridFocusX and y = m.gridFocusY
                    m.keyNodes[y][x].color = "0x000000FF"
                else
                    m.keyNodes[y][x].color = "0xCCCCCCFF"
                end if
            end for
        end for

        m.btnSpaceBg.color = "0x383838FF"
        m.btnClearBg.color = "0x383838FF"
        m.btnSearchBg.color = "0x383838FF"
    else
        m.focusCursor.visible = false
        for y = 0 to m.keys.Count() - 1
            for x = 0 to m.keys[y].Count() - 1
                m.keyNodes[y][x].color = "0xCCCCCCFF"
            end for
        end for

        if m.actionFocusIdx = 0
            m.btnSpaceBg.color = "0xFFFFFFFF"
            m.btnClearBg.color = "0x383838FF"
            m.btnSearchBg.color = "0x383838FF"
        else if m.actionFocusIdx = 1
            m.btnSpaceBg.color = "0x383838FF"
            m.btnClearBg.color = "0xFFFFFFFF"
            m.btnSearchBg.color = "0x383838FF"
        else if m.actionFocusIdx = 2
            m.btnSpaceBg.color = "0x383838FF"
            m.btnClearBg.color = "0x383838FF"
            m.btnSearchBg.color = "0xFFFFFFFF"
        end if
    end if
end sub

sub populateDefaultSuggestions()
    suggestions = ["coryxkenshin", "caseoh", "elden ring build", "lofi hip hop radio", "10 hours relaxing music"]
    for each item in suggestions
        pill = m.suggestionsGroup.createChild("Rectangle")
        pill.width = 360
        pill.height = 44
        pill.color = "0x383838FF"
        
        lbl = pill.createChild("Label")
        lbl.translation = [20, 11]
        lbl.width = 320
        lbl.text = item
        lbl.color = "0xDDDDDDFF"
        lbl.font = "font:SmallSystemFont"
    end for
end sub

sub triggerSearch()
    if m.currentText <> invalid and m.currentText.Trim() <> ""
        m.top.searchQuerySubmitted = m.currentText
    end if
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
    handled = false
    if press
        if m.focusMode = "grid"
            if key = "right"
                if m.gridFocusX < 6 then m.gridFocusX++ : updateFocusUI() : handled = true
            else if key = "left"
                if m.gridFocusX > 0 then m.gridFocusX-- : updateFocusUI() : handled = true
            else if key = "down"
                if m.gridFocusY < 3
                    m.gridFocusY++
                    updateFocusUI()
                else
                    m.focusMode = "actions"
                    m.actionFocusIdx = 0
                    updateFocusUI()
                end if
                handled = true
            else if key = "up"
                if m.gridFocusY > 0 then m.gridFocusY-- : updateFocusUI() : handled = true
            else if key = "OK"
                char = m.keys[m.gridFocusY][m.gridFocusX]
                m.currentText = m.currentText + char
                m.searchTextDisplay.text = m.currentText
                handled = true
            else if key = "back"
                if m.currentText.Len() > 0
                    m.currentText = m.currentText.Left(m.currentText.Len() - 1)
                    m.searchTextDisplay.text = m.currentText
                    handled = true
                end if
            end if

        else if m.focusMode = "actions"
            if key = "up"
                m.focusMode = "grid"
                updateFocusUI()
                handled = true
            else if key = "left"
                if m.actionFocusIdx > 0 then m.actionFocusIdx-- : updateFocusUI() : handled = true
            else if key = "right"
                if m.actionFocusIdx < 2 then m.actionFocusIdx++ : updateFocusUI() : handled = true
            else if key = "OK"
                if m.actionFocusIdx = 0 ' SPACE
                    m.currentText = m.currentText + " "
                    m.searchTextDisplay.text = m.currentText
                else if m.actionFocusIdx = 1 ' CLEAR
                    m.currentText = ""
                    m.searchTextDisplay.text = ""
                else if m.actionFocusIdx = 2 ' SEARCH
                    triggerSearch()
                end if
                handled = true
            end if
        end if
    end if
    return handled
end function