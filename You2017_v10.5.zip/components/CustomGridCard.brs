sub init()
    m.cardBg = m.top.findNode("cardBg")
    m.thumbnail = m.top.findNode("thumbnail")
    m.duration = m.top.findNode("duration")
    m.title = m.top.findNode("title")
    m.channel = m.top.findNode("channel")
    m.stats = m.top.findNode("stats")
end sub

sub itemContentChanged()
    item = m.top.itemContent
    if item <> invalid
        m.thumbnail.uri = item.HDPosterUrl
        m.title.text = item.title
        m.channel.text = item.shortDescriptionText
        m.stats.text = item.description
        m.duration.text = item.durationText
    end if
end sub

sub onFocusChanged()
    if m.top.itemHasFocus = true
        m.cardBg.color = "0xFFFFFFFF"
        m.title.color = "0x0C0C0CFF"
        m.channel.color = "0x606060FF"
        m.stats.color = "0x767676FF"
    else
        m.cardBg.color = "0x00000000"
        m.title.color = "0xFFFFFFFF"
        m.channel.color = "0xAAAAAAFF"
        m.stats.color = "0x888888FF"
    end if
end sub