sub init()
    m.videoRowList = m.top.findNode("videoRowList")
    m.sideNavGroup = m.top.findNode("sideNavGroup")
    m.navFocusIndicator = m.top.findNode("navFocusIndicator")
    m.subHeaderLabel = m.top.findNode("subHeaderLabel")
    m.mainHeaderLabel = m.top.findNode("mainHeaderLabel")
    m.headerGroup = m.top.findNode("headerGroup")
    m.searchScreen = m.top.findNode("searchScreen")
    m.playerScreen = m.top.findNode("playerScreen")
    
    m.selectedNavIndex = 1 
    m.sidebarFocused = false
    m.navPositions = [130, 225]

    m.searchScreen.observeField("searchQuerySubmitted", "onSearchSubmitted")
    m.videoRowList.observeField("rowItemFocused", "onRowItemFocused")
    m.videoRowList.observeField("rowItemSelected", "onVideoCardSelected")
    m.playerScreen.observeField("closePlayer", "onClosePlayer")

    fetchHomeFeed()
end sub

sub fetchHomeFeed()
    m.searchScreen.visible = false
    m.headerGroup.visible = true
    m.videoRowList.visible = true
    
    m.subHeaderLabel.text = "Recommended"
    m.mainHeaderLabel.text = "Recommended"

    m.ytTask = CreateObject("roSGNode", "YtTask")
    m.ytTask.searchQuery = ""
    m.ytTask.observeField("videoList", "onVideosReceived")
    m.ytTask.control = "RUN"
end sub

sub executeSearch(query as String)
    m.searchScreen.visible = false
    m.headerGroup.visible = true
    m.videoRowList.visible = true

    m.subHeaderLabel.text = "Search Results"
    m.mainHeaderLabel.text = "Results for: " + query

    m.ytTask = CreateObject("roSGNode", "YtTask")
    m.ytTask.searchQuery = query
    m.ytTask.observeField("videoList", "onVideosReceived")
    m.ytTask.control = "RUN"
end sub

sub onSearchSubmitted()
    query = m.searchScreen.searchQuerySubmitted
    if query <> invalid and query <> ""
        executeSearch(query)
    end if
end sub

sub onVideosReceived()
    videoData = m.ytTask.videoList
    if videoData = invalid or videoData.rows = invalid or videoData.rows.Count() = 0
        return
    end if

    rootContent = CreateObject("roSGNode", "ContentNode")

    for each rowData in videoData.rows
        rowNode = rootContent.CreateChild("ContentNode")
        if rowData.title <> invalid and rowData.title <> ""
            rowNode.title = rowData.title
        else
            rowNode.title = "Recommended"
        end if

        for each video in rowData.items
            item = rowNode.CreateChild("ContentNode")
            item.id = video.videoId 
            item.title = video.title
            
            ' CRITICAL FIX: Active Invidious domain + local=true proxy parameter
            if video.videoId <> invalid and video.videoId <> ""
                item.url = "https://inv.nadeko.net/latest_version?id=" + video.videoId + "&itag=22&local=true"
            else if video.url <> invalid and video.url <> ""
                item.url = video.url
            end if

            item.addField("HDPosterUrl", "string", false)
            item.HDPosterUrl = video.thumbnailUrl
            
            item.addField("shortDescriptionText", "string", false)
            item.shortDescriptionText = video.author
            
            item.addField("description", "string", false)
            item.description = video.viewCount
            
            item.addField("durationText", "string", false)
            item.durationText = video.lengthText
        end for
    end for

    m.videoRowList.content = rootContent
    m.videoRowList.setFocus(true)
    m.sidebarFocused = false
    if m.navFocusIndicator <> invalid
        m.navFocusIndicator.visible = false
    end if
end sub

sub updateSidebarFocusUI()
    if m.navFocusIndicator <> invalid
        m.navFocusIndicator.translation = [0, m.navPositions[m.selectedNavIndex]]
        m.navFocusIndicator.visible = true
    end if
end sub

sub onRowItemFocused()
    focusedItem = m.videoRowList.rowItemFocused
    if focusedItem <> invalid and focusedItem.Count() > 0
        rowIndex = focusedItem[0]
        if m.videoRowList.content <> invalid and rowIndex < m.videoRowList.content.getChildCount()
            rowTitle = m.videoRowList.content.getChild(rowIndex).title
            if rowTitle <> ""
                m.subHeaderLabel.text = rowTitle
                m.mainHeaderLabel.text = rowTitle
            end if
        end if
    end if
end sub

sub onVideoCardSelected()
    focused = m.videoRowList.rowItemSelected
    if focused <> invalid and focused.Count() > 1
        selectedItem = m.videoRowList.content.getChild(focused[0]).getChild(focused[1])
        if selectedItem <> invalid
            print "--- PLAYING ITEM: "; selectedItem.title
            print "--- STREAM URL: "; selectedItem.url
            
            m.playerScreen.videoContent = selectedItem
            m.playerScreen.visible = true
            m.playerScreen.setFocus(true)
        end if
    end if
end sub

sub onClosePlayer()
    if m.playerScreen.closePlayer = true
        m.playerScreen.visible = false
        m.videoRowList.setFocus(true)
        m.playerScreen.closePlayer = false
    end if
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
    handled = false
    
    if press
        if m.playerScreen.visible
            return false
        end if

        if key = "left"
            focusedItem = m.videoRowList.rowItemFocused
            if not m.sidebarFocused and (m.searchScreen.visible or (focusedItem <> invalid and focusedItem.Count() > 1 and focusedItem[1] = 0))
                m.sidebarFocused = true
                updateSidebarFocusUI()
                m.sideNavGroup.setFocus(true)
                handled = true
            end if

        else if key = "right"
            if m.sidebarFocused
                m.sidebarFocused = false
                if m.navFocusIndicator <> invalid
                    m.navFocusIndicator.visible = false
                end if
                if m.searchScreen.visible
                    m.searchScreen.setFocus(true)
                else
                    m.videoRowList.setFocus(true)
                end if
                handled = true
            end if

        else if key = "up"
            if m.sidebarFocused
                if m.selectedNavIndex > 0
                    m.selectedNavIndex--
                    updateSidebarFocusUI()
                end if
                handled = true
            end if

        else if key = "down"
            if m.sidebarFocused
                if m.selectedNavIndex < m.navPositions.Count() - 1
                    m.selectedNavIndex++
                    updateSidebarFocusUI()
                end if
                handled = true
            end if

        else if key = "OK"
            if m.sidebarFocused
                if m.selectedNavIndex = 0
                    m.headerGroup.visible = false
                    m.videoRowList.visible = false
                    m.searchScreen.visible = true
                    m.searchScreen.setFocus(true)
                else if m.selectedNavIndex = 1
                    fetchHomeFeed()
                end if
                handled = true
            end if
        end if
    end if
    
    return handled
end function