sub init()
    m.top.functionName = "loadTrendingVideos"
end sub

sub loadTrendingVideos()
    searchQuery = m.top.searchQuery
    parsedRows = []

    if searchQuery <> invalid and searchQuery <> ""
        print "--- Executing Search Query: "; searchQuery; " ---"
        items = fetchSearchResults(searchQuery)
        if items.Count() > 0
            parsedRows.Push({
                title: "Results for: " + searchQuery,
                items: items
            })
        end if
    else
        print "--- Starting Standard Multi-Row Home Request ---"
        rowConfigs = [
            { title: "Recommended", channelId: "UCBR8-60-B28hp2BmDPdntcQ" },
            { title: "Gaming", channelId: "UCKy1dAqELo0zrOtPkf0eTMw" },
            { title: "Nintendo World", channelId: "UCGIY_O-8vW4rfXjHYvBFV0w" },
            { title: "Tech & Science", channelId: "UCX6b17PVsYBQ0ip5gyeme-Q" }
        ]

        for each config in rowConfigs
            items = fetchChannelVideos(config.channelId)
            if items.Count() > 0
                parsedRows.Push({
                    title: config.title,
                    items: items
                })
            end if
        end for
    end if

    resultWrapper = CreateObject("roAssociativeArray")
    resultWrapper["rows"] = parsedRows
    m.top.videoList = resultWrapper
end sub

function fetchSearchResults(query as String) as Object
    request = CreateObject("roUrlTransfer")
    port = CreateObject("roMessagePort")
    request.SetMessagePort(port)
    
    encodedQuery = request.UrlEncode(query)
    url = "https://www.youtube.com/results?search_query=" + encodedQuery + "&pbj=1"
    request.SetUrl(url)
    request.AddHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
    request.AddHeader("X-YouTube-Client-Name", "1")
    request.AddHeader("X-YouTube-Client-Version", "2.20231118.00.00")
    
    request.EnablePeerVerification(false)
    request.EnableHostVerification(false)

    videoArray = []

    if request.AsyncGetToString()
        msg = wait(5000, port)
        if type(msg) = "roUrlEvent" and msg.GetResponseCode() = 200
            jsonText = msg.GetString()
            if jsonText <> invalid and jsonText <> ""
                videoArray = parseSearchResultsFromJson(jsonText)
            end if
        end if
    end if
    
    return videoArray
end function

function parseSearchResultsFromJson(jsonText as String) as Object
    videoArray = []
    
    regex = CreateObject("roRegex", """videoId"":""([^""]+)""", "")
    matches = regex.MatchAll(jsonText)
    
    if matches <> invalid and matches.Count() > 0
        addedIds = {}
        for each match in matches
            if match.Count() > 1
                vId = match[1]
                if not addedIds.DoesExist(vId) and vId.Len() = 11
                    addedIds[vId] = true
                    
                    videoArray.Push({
                        videoId: vId,
                        title: "Video (" + vId + ")",
                        author: "YouTube Search Result",
                        viewCount: "Search Result",
                        lengthText: "HD",
                        thumbnailUrl: "https://i.ytimg.com/vi/" + vId + "/hqdefault.jpg"
                    })
                end if
            end if
            if videoArray.Count() >= 15 then exit for
        end for
    end if

    return videoArray
end function

function fetchChannelVideos(channelId as String) as Object
    request = CreateObject("roUrlTransfer")
    port = CreateObject("roMessagePort")
    request.SetMessagePort(port)
    
    request.SetUrl("https://www.youtube.com/feeds/videos.xml?channel_id=" + channelId)
    request.EnablePeerVerification(false)
    request.EnableHostVerification(false)

    if request.AsyncGetToString()
        msg = wait(5000, port)
        if type(msg) = "roUrlEvent" and msg.GetResponseCode() = 200
            xmlText = msg.GetString()
            if xmlText <> invalid and xmlText <> ""
                xml = CreateObject("roXMLElement")
                if xml.Parse(xmlText)
                    return parseRssFeed(xml)
                end if
            end if
        end if
    end if
    return []
end function

function parseRssFeed(xml as Object) as Object
    videoArray = []
    entries = xml.GetNamedElements("entry")

    for each entry in entries
        videoObj = {
            videoId: "",
            title: "Untitled Video",
            author: "YouTube Channel",
            viewCount: "100K views",
            lengthText: "HD",
            thumbnailUrl: ""
        }

        ytId = entry.GetNamedElements("yt:videoId")
        if ytId.Count() > 0 then videoObj.videoId = ytId[0].GetText()

        titleNode = entry.GetNamedElements("title")
        if titleNode.Count() > 0 then videoObj.title = titleNode[0].GetText()

        authorNode = entry.GetNamedElements("author")
        if authorNode.Count() > 0
            nameNode = authorNode[0].GetNamedElements("name")
            if nameNode.Count() > 0 then videoObj.author = nameNode[0].GetText()
        end if

        if videoObj.videoId <> ""
            videoObj.thumbnailUrl = "https://i.ytimg.com/vi/" + videoObj.videoId + "/hqdefault.jpg"
            videoArray.Push(videoObj)
        end if
    end for

    return videoArray
end function