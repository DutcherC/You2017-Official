sub init()
    m.videoPlayer = m.top.findNode("videoPlayer")
    m.overlayGroup = m.top.findNode("overlayGroup")
    m.loadingGroup = m.top.findNode("loadingGroup")
    m.loadingText = m.top.findNode("loadingText")
    m.videoTitle = m.top.findNode("videoTitle")
    m.videoMetadata = m.top.findNode("videoMetadata")
    m.timeElapsed = m.top.findNode("timeElapsed")
    m.timeTotal = m.top.findNode("timeTotal")
    m.progressBar = m.top.findNode("progressBar")
    m.scrubberKnob = m.top.findNode("scrubberKnob")
    m.btnPlayIcon = m.top.findNode("btnPlayIcon")
    m.playLabel = m.top.findNode("playLabel")

    m.overlayVisible = true
    if m.videoPlayer <> invalid
        m.videoPlayer.observeField("position", "handlePositionChange")
        m.videoPlayer.observeField("state", "handlePlayerStateChange")
    end if
end sub

sub handleContentChange()
    item = m.top.videoContent
    if item <> invalid and m.videoPlayer <> invalid
        if item.title <> invalid then m.videoTitle.text = item.title
        
        if m.loadingGroup <> invalid 
            m.loadingGroup.visible = true
            if m.loadingText <> invalid then m.loadingText.text = "Loading stream..."
        end if
        
        m.videoPlayer.notificationInterval = 0.5
        m.videoPlayer.control = "stop"

        m.resolverTask = CreateObject("roSGNode", "StreamResolverTask")
        m.resolverTask.videoId = item.id
        m.resolverTask.observeField("resolvedUrl", "onStreamResolved")
        m.resolverTask.control = "RUN"
    end if
end sub

sub onStreamResolved()
    streamUrl = m.resolverTask.resolvedUrl

    if streamUrl = invalid or streamUrl = ""
        if m.loadingText <> invalid then m.loadingText.text = "Playback Error"
        print "--- ERROR: Could not resolve stream URL for video."
        return
    end if

    print "--- PLAYING REMUXED TS STREAM: "; streamUrl

    videoContent = CreateObject("roSGNode", "ContentNode")
    videoContent.url = streamUrl
    videoContent.title = m.videoTitle.text
    videoContent.streamFormat = "ts"
    videoContent.live = true
    videoContent.contentType = "vod"

    m.videoPlayer.content = videoContent
    m.videoPlayer.control = "play"
end sub

sub handlePositionChange()
    if m.videoPlayer = invalid then return
    curPos = m.videoPlayer.position
    curDur = m.videoPlayer.duration

    if curDur <> invalid and curDur > 0
        pSec = Int(curPos)
        pMin = Int(pSec / 60)
        pRem = pSec mod 60
        
        sStr = pRem.ToStr()
        if pRem < 10 then sStr = "0" + sStr
        m.timeElapsed.text = pMin.ToStr() + ":" + sStr

        dSec = Int(curDur)
        dMin = Int(dSec / 60)
        dRem = dSec mod 60
        
        dStr = dRem.ToStr()
        if dRem < 10 then dStr = "0" + dStr
        m.timeTotal.text = dMin.ToStr() + ":" + dStr
        
        ratio = curPos / curDur
        newW = 1600 * ratio
        m.progressBar.width = newW
        m.scrubberKnob.translation = [newW, -6]
    end if
end sub

sub handlePlayerStateChange()
    if m.videoPlayer = invalid then return
    st = m.videoPlayer.state

    if st = "buffering"
        if m.loadingGroup <> invalid then m.loadingGroup.visible = true
    else if st = "playing"
        if m.loadingGroup <> invalid then m.loadingGroup.visible = false
        m.playLabel.text = "Pause"
        m.btnPlayIcon.uri = "pkg:/images/icon_pause.png"
    else if st = "paused"
        if m.loadingGroup <> invalid then m.loadingGroup.visible = false
        m.playLabel.text = "Play"
        m.btnPlayIcon.uri = "pkg:/images/icon_play.png"
        m.overlayGroup.visible = true
        m.overlayVisible = true
    else if st = "error"
        if m.loadingGroup <> invalid then m.loadingGroup.visible = false
        print "--- Video Player Error: "; m.videoPlayer.errorCode; " | "; m.videoPlayer.errorMsg
    end if
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
    handled = false
    if press and m.videoPlayer <> invalid
        if key = "OK" or key = "play"
            if m.videoPlayer.state = "playing"
                m.videoPlayer.control = "pause"
                m.overlayVisible = true
                m.overlayGroup.visible = true
            else
                m.videoPlayer.control = "resume"
                m.overlayVisible = false
                m.overlayGroup.visible = false
            end if
            handled = true

        else if key = "down" or key = "up" or key = "left" or key = "right"
            if m.overlayVisible
                if key = "down"
                    m.overlayVisible = false
                    m.overlayGroup.visible = false
                end if
            else
                m.overlayVisible = true
                m.overlayGroup.visible = true
            end if
            handled = true

        else if key = "back"
            if m.overlayVisible
                m.overlayVisible = false
                m.overlayGroup.visible = false
                handled = true
            else
                m.videoPlayer.control = "stop"
                m.top.closePlayer = true
                handled = true
            end if
        end if
    end if
    return handled
end function